<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Tablelize Language File
    |--------------------------------------------------------------------------
    |
    | This file includes some of the texts shown in the html table generates
    |
    */

    'search'       => 'Search',
    'actions'      => 'Actions',
    'noEntriesMsg' => 'No entries found.',
    'beforeSize'   => 'Show',
    'afterSize'    => 'entries',
];
